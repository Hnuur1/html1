//SYNTAX PARSER - SOMETHING THAT READS AND TRANSLATE YOUR CODE-

//var a = 'Hello World!';



console.log("web page is linked"); // checking the console to see if the website is linked


//name value pair in the execution contect -

var nameOfVariable; // declaring the variable

nameOfVariable = "Hello"; //initialing

var test = "Hello"; // assigning a datatype

console.log(test);

test = "Bye"; //changing value

console.log(test); //check what the script is doing


// declaring a function

function nameOfFunction() {

    var text;
    text = "this is javascript week";

    console.log("this is javascript week");
}

function secondFunction() {

    var maths = (2 + 4);
    console.log(maths);

}

nameOfFunction(); // runs our function
secondFunction();

window.alert("Hello!");


var _eventListner = document.getElementById("userButton").addEventListener('click', displayA);


console.log("Function is working");

function addSums() {

    var userInput =
        parseInt(document.getElementById("ourUserInput").value);
    var secondInput =
        parseInt(document.getElementById("secondUserInput").value);
    var thirdInput =
        parseInt(document.getElementById("thirdUserInput").value);

    var firstsum = parseInt(userInput + secondInput + thirdInput) * parseInt(thirdInput);
    var secondsum = parseInt(userInput + secondInput + thirdInput);

    document.getElementById("displayResult").innerHTML = firstsum - secondsum;

    var inputDisply = firstsum - secondsum;

    window.alert("this is the answer" + inputDisply);
}




function displayD() {

    var inputA =
        parseInt(document.getElementById("ourUserInput").value);
    var inputB =
        parseInt(document.getElementById("secondUserInput").value);
    var inputC =
        parseInt(document.getElementById("thirdUserInput").value);

    document.getElementById("displayResult").innerHTML = inputA + inputB + inputC;

}

displayD();






function displayA() {

    var sameVar = 6;
    document.getElementById("displayResult").innerHTML = sameVar;
    console.log(sameVar);
}

displayA();

var sameVar = 8;
document.getElementById("displayResultA").innerHTML = sameVar;
console.log(sameVar);



function 





//
//var message = document.getElementById("ourUserInput", "secondUserInput", "thirdUserInput");
//document.getElementById("myButton").addEventListener("click", function () {
//    console.log(message.value);
//});



//function displaysum = () {
//
//    var Input = document.getElementById("ourUserInput", "secondUserInput", "thirdUserInput");
//    window.alert(Input);
//    console.log(Input);
//}
//
//displaysum();

//
//    window.alert Input;
//
//}
//
//displaysum();
//
//var message = document.getElementById("message");
//document.getElementById("myButton").addEventListener("click", function() {
//    console.log( message.value );
//});
//
